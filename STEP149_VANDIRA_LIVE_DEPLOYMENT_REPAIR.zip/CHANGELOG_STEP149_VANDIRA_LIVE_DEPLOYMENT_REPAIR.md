# STEP149 — VANDIRA Live Deployment Repair

## Problem
The deployed `pages.dev` site returned `index.html` as visible plain text instead of rendering HTML.

## Root cause identified
The project had a root `functions/_middleware.js`. Cloudflare Pages documentation confirms that a root middleware runs on the entire application, including static files. The middleware reconstructed every response, which interfered with native Pages static-asset serving and MIME handling.

## Repair
1. Removed the global `functions/_middleware.js`.
2. Moved the same API security/rate-limit/observability middleware to `functions/api/_middleware.js`, with corrected relative imports.
3. Preserved response status/statusText/headers when wrapping API responses.
4. Replaced the malformed `_headers` file with valid Cloudflare Pages header rules.
5. Added explicit `Content-Type: text/html; charset=UTF-8` rules for `/` and root HTML pages.
6. Added `_routes.json` so only `/api/*` invokes Pages Functions; static pages/assets remain native Pages static responses.

## Data policy
No election, booth, Form20, party, candidate, or canonical data files were modified.
